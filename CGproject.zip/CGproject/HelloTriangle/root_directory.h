#pragma once
const char * logl_root = "${CMAKE_SOURCE_DIR}";